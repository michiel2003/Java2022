package fact.it.exrefuelling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExRefuellingApplication {

    public static void main(String[] args) {

        SpringApplication.run(ExRefuellingApplication.class, args);
        // write code starting after this line



        System.exit(0);

    }

}
