package fact.it.exthermostat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExThermostatApplication {

    public static void main(String[] args) {

        SpringApplication.run(ExThermostatApplication.class, args);
        // write code starting after this line



        System.exit(0);
    }

}
