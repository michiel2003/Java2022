package fact.it.exline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExLineApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExLineApplication.class, args);
        // write code starting after this line


        System.exit(0);
    }

}
